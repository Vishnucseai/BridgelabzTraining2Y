class WelcomeToBridgelabz{
    public static void main(String[] args) {
	
	System.out.println("Welocome to Bridgelabz!");
	}
}	